﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Term_project_UN
{
    public partial class Form1 : Form
    {

        int correctAnswer;
        int questionNumber = 1;
        int score;
        int percentage;
        int totalQuestions;



        public Form1()
        {
            InitializeComponent();

            askQuestion(questionNumber);

            totalQuestions = 8;


        }

        private void checkAnswerEvent(object sender, EventArgs e)
        {
            var senderObject = (Button)sender;

            int buttonTag = Convert.ToInt32(senderObject.Tag);

            if (buttonTag == correctAnswer) 
            {
                score++;
            }

            if(questionNumber == totalQuestions)
            {
                percentage = (int)Math.Round((double)(score * 100) / totalQuestions);


                MessageBox.Show(
                    "Quiz has finished" + Environment.NewLine +
                    "You have answered on " +  score + "question correctly." + Environment.NewLine +
                    "Your total percentage is " + percentage + "%" + Environment.NewLine +
                    "Click OK to play again " 
                    );

                score = 0;
                questionNumber = 0;
                askQuestion(questionNumber);
            }


            questionNumber++;
            askQuestion(questionNumber);


        }


        private void askQuestion(int qnum)
        {


            switch(qnum)
            {
                case 1:
                    pictureBox1.Image = Properties.Resources.q11;

                    lblQuestion.Text = "What the value has number pi ?";

                    button1.Text = "3.12";
                    button2.Text = "3.14";
                    button3.Text = "3.16";
                    button4.Text = "3.10";


                    correctAnswer = 2;

                    break;

                case 2:
                    pictureBox1.Image = Properties.Resources.q2;

                    lblQuestion.Text = "Which is the best selling record in history ?";

                    button1.Text = "Thriller Michael Jakson";
                    button2.Text = "A kind of Magic – Queen";
                    button3.Text = "Help – the Beatles";
                    button4.Text = "Bob Marley sun is shining";


                    correctAnswer = 1;

                    break;
                case 3:
                    pictureBox1.Image = Properties.Resources.q3;

                    lblQuestion.Text = "In which greek city the Olympic games began ?";

                    button1.Text = "Sparta";
                    button2.Text = "Athens";
                    button3.Text = "Corinth";
                    button4.Text = "Olympia";


                    correctAnswer = 4;

                    break;
                case 4:
                    pictureBox1.Image = Properties.Resources.q4;

                    lblQuestion.Text = "What is the hottest planet in our solar system ?";

                    button1.Text = "Saturn";
                    button2.Text = "Venus";
                    button3.Text = "Jupiter";
                    button4.Text = "Mercury";


                    correctAnswer = 2;

                    break;
                case 5:
                    pictureBox1.Image = Properties.Resources.q5;

                    lblQuestion.Text = "What year was Mukay Elebaev had born?";

                    button1.Text = "1906"; 
                    button2.Text = "1901";
                    button3.Text = "1908";
                    button4.Text = "1903";


                    correctAnswer = 1;

                    break;
                case 6:
                    pictureBox1.Image = Properties.Resources.q6;

                    lblQuestion.Text = "Who painted the famous “The Starry Night” ?";

                    button1.Text = "Salvador Dali";
                    button2.Text = "Pablo Picasso";
                    button3.Text = "Vincent van Gogh";
                    button4.Text = "Jan Vermeer";


                    correctAnswer = 3;

                    break;
                case 7:
                    pictureBox1.Image = Properties.Resources.q7;

                    lblQuestion.Text = "Which number logically follows this series  ?" + Environment.NewLine +
                     "4  6  9  6  14  6  …";

                    button1.Text = "6";
                    button2.Text = "24";
                    button3.Text = "19";
                    button4.Text = "12";


                    correctAnswer = 3;

                    break;
                case 8:
                    pictureBox1.Image = Properties.Resources.q8;

                    lblQuestion.Text = "Which music video on YouTube has the most views ?";

                    button1.Text = "Shape of You";
                    button2.Text = "See You Again";
                    button3.Text = "Despacito";
                    button4.Text = "Baby Shark Sance";


                    correctAnswer = 4;

                    break;


            }




        }
    }
}
